package com.qa.Testcases;

import com.qa.Testbase.BaseClass;

public class ContactsPageTest extends BaseClass {

}
