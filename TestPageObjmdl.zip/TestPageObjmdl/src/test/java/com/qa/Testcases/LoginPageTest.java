package com.qa.Testcases;

import com.qa.Pages.HomePage;
import com.qa.Pages.LoginPage;
import com.qa.Testbase.BaseClass;


import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
//import org.testng.annotations.Test;

public class LoginPageTest extends BaseClass {

	LoginPage loginpage;
	HomePage homepage;
	
	public LoginPageTest () {
		super();
		System.out.println("test at Constr");
	}
	
	@BeforeMethod
	//public void SetUp () {
		//Initialization ();
		//loginpage.Login(Prop.getProperty("Username"), Prop.getProperty("Password"));
		//}
	
	@Test
	public void validateLoginPageTest () {
		Initialization ();
		homepage=loginpage.Login(Prop.getProperty("Username"), Prop.getProperty("Password"));
	}
	
	@AfterMethod
	public void QuitBrowser () {
		driver.quit();
	}
	
	
	
}
