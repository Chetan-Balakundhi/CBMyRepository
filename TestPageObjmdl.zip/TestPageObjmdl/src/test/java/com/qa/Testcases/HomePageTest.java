package com.qa.Testcases;

import com.qa.Testbase.BaseClass;

public class HomePageTest extends BaseClass {

}
