 package com.qa.Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.Testbase.BaseClass;

//import pageClasses.HomePage;

public class LoginPage extends BaseClass {

	HomePage homepage;
	@FindBy(xpath="//input[@name='email']")
	WebElement Username;
	
	@FindBy(xpath="//input[@name='password']")
	WebElement Password;
			
	@FindBy(xpath="//div[text()='Login']")
	WebElement LoginButton; 
	
	
	public LoginPage () {
		PageFactory.initElements(driver, this);
	}
	
	public HomePage Login (String Usname, String Psswd) {
    
		Username.sendKeys(Usname);
		Password.sendKeys(Psswd);
		//homepage=LoginButton.click();
		LoginButton.click();
		return homepage;
		
	}
	
}
