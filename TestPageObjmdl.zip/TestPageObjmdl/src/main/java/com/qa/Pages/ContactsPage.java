package com.qa.Pages;

public class ContactsPage {

}
