package com.qa.Pages;

public class HomePage {

}
