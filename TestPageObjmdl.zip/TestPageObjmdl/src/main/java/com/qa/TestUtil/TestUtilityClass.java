package com.qa.TestUtil;

import com.qa.Testbase.BaseClass;

public class TestUtilityClass extends BaseClass {

}
